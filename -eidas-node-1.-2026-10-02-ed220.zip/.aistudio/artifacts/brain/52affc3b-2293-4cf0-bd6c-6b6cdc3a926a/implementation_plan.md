# Google OAuth Client & Pre-Filled Identity Gate Resolution

Resolves the `Error 401: invalid_client` authorization block on the Credentials Hub login gate by eliminating the defunct hardcoded OAuth client fallback, dynamically loading the user's configured Google OAuth Client ID from environment variables, and providing a pre-filled custom profile sign-in form with full server-side session and audit log verification.

## User Review & Critical Decisions

> [!IMPORTANT]
> The implementation plan below reflects your confirmed preferences from our clarification step:

- **Confirmed Decision 1 (Environment-Driven Google OAuth Client ID)**: Remove the defunct hardcoded fallback client ID that caused Google's `401: invalid_client` popup error. The application will read your custom OAuth Client ID dynamically from `GOOGLE_CLIENT_ID` or `VITE_GOOGLE_CLIENT_ID` via a runtime configuration endpoint so changes to environment variables take effect without rebuilding static bundles.
- **Confirmed Decision 2 (Pre-Filled Custom Profile Sign-In Experience)**: Provide an interactive identity sign-in form on the login gate pre-populated with `daniele.palagi92@gmail.com` and `Daniele Palagi` (fully editable for custom profiles), enabling immediate sign-in and audit-logged session creation even before external Google Cloud OAuth credentials are configured.

---

## 1. Overview & Core Concept

- **What It Does**: Eliminates the broken OAuth popup error by detecting whether a valid Google OAuth 2.0 Client ID is present in the runtime environment. When configured, it initializes the official Google Identity Services (GIS) sign-in button with your Client ID; simultaneously, it offers a pre-filled Direct Identity Verification form (`daniele.palagi92@gmail.com`) and the Swiss Sovereign Sandbox evaluator bypass.
- **Target Audience / Persona**: Compliance officers, cryptographic evaluators, and administrators accessing the Project Bilanx eIDAS 2.0 Node & Dual-Key Sovereign Validation System.
- **Key Value**: Prevents dead-end `401: invalid_client` errors in iframe preview and production environments while preserving cryptographic session tokens and immutable Local Access Log Database auditing across all authentication methods.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Runtime OAuth Detection**: On load, the Authentication Gate queries the server's runtime auth configuration. If `GOOGLE_CLIENT_ID` or `VITE_GOOGLE_CLIENT_ID` is configured, the official Google Sign-In button renders and authenticates against Google Identity Services.If not yet set, a concise configuration guide displays the current origin URL to authorize in Google Cloud Console along with instructions to set `GOOGLE_CLIENT_ID`.
  2. **Pre-Filled Custom Profile Sign-In**: Users can immediately sign in using the pre-filled email (`daniele.palagi92@gmail.com`) and display name (`Daniele Palagi`), or edit either field to test custom operator identities. Submitting the form dispatches a signed session request to the backend, records a `LOGIN_SUCCESS` audit entry, and opens the dashboard.
  3. **Audit Trail Inspection**: From either the gate screen or the authenticated workspace header, operators can open the Access Log Audit Modal to inspect, filter, or export CSV records of all login and verification events.
- **Visual Identity & Theme**:
  - *Aesthetic Direction*: High-trust sovereign security & enterprise compliance console.
  - *Color Palette & Mood*: Deep slate canvas (`#020617` / `bg-slate-950`), structured slate surfaces (`#0f172a` / `bg-slate-900`) with hairline `1px` borders (`border-slate-800`), royal blue primary accents (`#2563eb` / `bg-blue-600`) for identity verification actions, and emerald/crimson semantic indicators paired with explicit text labels.
  - *Typography & Hierarchy*: `Outfit` for clean geometric display headers and form controls, paired with `JetBrains Mono` (`tabular-nums`) for session identifiers, origins, and audit timestamps.
  - *Component Styling & Layout*: Single-elevation card container on the authentication gate with clean hairline dividers separating the Pre-Filled Profile form, the Google OAuth 2.0 GIS slot, and the Swiss Demonstration Sandbox action.
- **Interactive Feedback & Motion**: Immediate loading spinner feedback (`isVerifying`) on the sign-in button during token verification, inline dismissible error banner if verification fails, and smooth transition into the main Bilanx workspace.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Runtime Auth Config Endpoint vs. Build-Time Only Env Vars**
  - *Chosen Approach*: Expose a lightweight `GET /api/auth/config` endpoint that reads `GOOGLE_CLIENT_ID` and `VITE_GOOGLE_CLIENT_ID` at server runtime, combined with `import.meta.env.VITE_GOOGLE_CLIENT_ID` on the client.
  - *Why*: In containerized environments, setting `GOOGLE_CLIENT_ID` in `.env` or runtime secrets should work immediately without requiring a full frontend bundle rebuild.
  - *Alternatives Considered*: Relying solely on `import.meta.env.VITE_GOOGLE_CLIENT_ID`, which misses server-side `GOOGLE_CLIENT_ID` variables and requires rebuilding static assets.
- **Decision 2: Dual-Mode Token Verification on Backend**
  - *Chosen Approach*: When a real Google GIS ID token is submitted with a configured `GOOGLE_CLIENT_ID`, verify it cryptographically via `google-auth-library` (`verifyIdToken`). When the user signs in via the pre-filled Direct Identity Verification form, validate the structured JWT payload claims, issue a real server session token in `globalSessionStore`, and log the event in the Local Access Log Database.
  - *Why*: Ensures both real Google OAuth 2.0 tokens and direct profile sign-ins produce first-class server sessions (`sessionToken` + HTTP cookie) and complete audit trail entries.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```
┌──────────────────────────────────────────────────────────────────────────┐
│                        Authentication Gate UI                            │
│  ┌────────────────────────────────────┐  ┌────────────────────────────┐  │
│  │  Pre-Filled Profile Sign-In Form   │  │  Google Identity Services  │  │
│  │  • Email: daniele.palagi92@...     │  │  • Active when Client ID   │  │
│  │  • Name:  Daniele Palagi           │  │    configured in env vars  │  │
│  └─────────────────┬──────────────────┘  └─────────────┬──────────────┘  │
└────────────────────┼───────────────────────────────────┼─────────────────┘
                     │                                   │
                     ▼                                   ▼
┌──────────────────────────────────────────────────────────────────────────┐
│                        Client Auth Controller                            │
│  • Fetches GET /api/auth/config for runtime GOOGLE_CLIENT_ID             │
│  • Dispatches POST /api/auth/verify-google with credential & profile     │
└────────────────────────────────────┬─────────────────────────────────────┘
                                     │
                                     ▼
┌──────────────────────────────────────────────────────────────────────────┐
│                        Express Auth Backend                              │
│  • GET  /api/auth/config        -> Returns active Client ID & status     │
│  • POST /api/auth/verify-google -> Verifies GIS ID token or Direct JWT   │
│  • Issues Session Token (globalSessionStore) + Writes Access Log Record  │
└──────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - `AuthConfig`: `{ oauthConfigured: boolean; googleClientId: string | null }` fetched on gate initialization.
  - `VerifiedGoogleUser`: `{ uid, email, name, picture, emailVerified, issuer, authenticatedAt, sessionToken }` persisted in `localStorage` and backed by `globalSessionStore` on the server.
- **Interactive Component & State Mapping**:
  - **Profile Form Inputs (`emailInput`, `nameInput`)**: Initialized to `daniele.palagi92@gmail.com` and `Daniele Palagi`; controlled inputs with validation ensuring non-empty email before submission.
  - **Primary Sign-In Handler**: Calls `onInstantVerify(emailInput, nameInput)`, sets `isVerifying` loading state, posts to `/api/auth/verify-google`, stores the returned `VerifiedGoogleUser` + `sessionToken`, and transitions to `BilanxApp`.
  - **Dynamic GIS Button Renderer**: Initializes `window.google.accounts.id` only when `googleClientId` is non-empty and not equal to the retired placeholder ID; displays the current `window.location.origin` copy-helper when unconfigured so the user can easily configure their Google Cloud OAuth Client.
